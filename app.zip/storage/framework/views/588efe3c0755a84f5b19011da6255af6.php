<?php $__env->startSection('content'); ?>
    <div class="container" style="width: 650px">
        <div class="card">
            <div class="card-header">
                <?php echo e(__('New Work Order')); ?>

            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('user.work_orders.store')); ?>"
                      enctype="multipart/form-data"
                      id="createWOForm">
                    <?php echo csrf_field(); ?>
                    <div class="m-auto " style="width: 650px"  >
                        <div class="row">
                            <div class="col">
                                <div class="form-group mb-2">
                                    <label id="number_wo_label" for="number_wo"><?php echo e('Work Order Number'); ?></label>
                                    <input id="number_wo" class="form-control" style="width: 250px;height: 30px"
                                           name="number_wo" min="100000"
                                           oninput="this.value=this.value.slice(0,this.dataset.maxlength)"
                                           type="number" data-maxlength="6">
                                    <div id="number_wo_error" class="m-1 text-danger" style="font-size: 12px"></div> <!-- Ошибка -->
                                </div>
                                <div class="form-group mb-2">
                                    <label  for="open_at"><?php echo e('Open'); ?></label>
                                    <input id='open_at' type="date" class="form-control" name="open_at"
                                           style="width: 250px; height: 30px" required>
                                </div>
                                <div class="form-group ">
                                    <div class="row mb-2">
                                        <div class="col">
                                            <div class="">
                                                <label for="unit_id" class="form-label"><?php echo e(__('Unit PN')); ?></label>
                                                <select id="unit_id" name="unit_id"
                                                        class="form-select"
                                                        style="width:160px" required>
                                                    <option value=""><?php echo e(__('Select unit')); ?></option>
                                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->part_number); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                                        data-bs-target="#addUnitModal"><?php echo e(__('Add Unit')); ?></button>

                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class=" ">
                                                <label
                                                    for="amdt" class="mb-2 "><?php echo e('Amdt'); ?></label>
                                                <input  id="amdt"
                                                        class="form-control"
                                                        style="width: 70px; height: 30px"
                                                        name="amdt"
                                                        type = "text">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group mb-2">
                                    <label  for="serial_number"><?php echo e('Serial Number'); ?></label>
                                    <input  id="serial_number" class="form-control" style="width: 250px; height: 30px"
                                            name="serial_number"
                                            type = "text">
                                </div>

                            </div>
                            <div class="col">
                                <div class="form-group mb-2">
                                    <label for="instruction_id"><?php echo e(__('Instruction')); ?></label>
                                    <select id="instruction_id" name="instruction_id" class="form-control"
                                            style="width:250px; height: 32px" required>
                                        <option value=""><?php echo e(__('Select Instruction')); ?></option>
                                        <?php $__currentLoopData = $instructions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instruction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($instruction->id); ?>"><?php echo e($instruction->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                            data-bs-target="#addInstructionModal"><?php echo e(__('Add Instruction')); ?></button>
                                </div>
                                <div class="form-group">
                                    <label for="customer_id"><?php echo e(__('Customer')); ?></label>
                                    <select id="customer_id" name="customer_id" class="form-control"  style="width:
                            250px" required>
                                        <option value=""><?php echo e(__('Select Customer')); ?></option>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                            data-bs-target="#addCustomerModal"><?php echo e(__('Add Customer')); ?></button>
                                </div>
                                <div class="form-group">
                                    <label for="user_id"><?php echo e(__('Technician')); ?> </label>
                                    <select id="user_id" name="user_id" class="form-control"  style="width:
                            250px" required>
                                        <option value=""><?php echo e(__('Select Technician')); ?></option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="note"><?php echo e(__('Note')); ?> </label>
                            <textarea class="form-control" id="note" rows="3" name="notes" style="width:
                            580px" ></textarea>

                        </div>

                    </div>
                    <button type="submit" class="btn btn-primary mt-3">
                        <?php echo e(__('Add Work Order')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Модальное окно для добавления Instruction -->
        <div class="modal fade" id="addInstructionModal" tabindex="-1" aria-labelledby="addInstructionModalLabel"
             aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addInstructionModalLabel">
                            <?php echo e(__('Add Instruction')); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" id="addInstructionForm">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="instructionName"><?php echo e(__('Instruction')); ?></label>
                                <input type="text" class="form-control"
                                       id="instructionName" name="name" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    <!-- Модальное окно для добавления Customer -->
    <div class="modal fade" id="addCustomerModal" tabindex="-1"
         aria-labelledby="addCustomerModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCustomerModalLabel">
                        <?php echo e(__('Add Customer')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="addCustomerForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="customerName"><?php echo e(__('Customer')); ?></label>
                            <input type="text" class="form-control"
                                   id="customerName" name="name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <!-- Модальное окно для добавления Unit -->
    <div class="modal fade" id="addUnitModal" tabindex="-1"
         aria-labelledby="addUnitModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUnitModalLabel">
                        <?php echo e(__('Add Unit')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="addUnitForm" action="<?php echo e(route('user.unit.storeWorkorder')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="cmmSelect" class="form-label">Select CMM</label>
                            <select class="form-select" id="cmmSelect" name="manual_id" required>
                                <option value=""><?php echo e(__('Select CMM')); ?></option>
                                <?php $__currentLoopData = $manuals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($manual->id); ?>"><?php echo e($manual->title); ?> (<?php echo e($manual->number); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="unitName"><?php echo e(__('Unit')); ?></label>
                            <input type="text" class="form-control"
                                   id="unitName" name="part_number" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>


    <script src="<?php echo e(asset('js/jquery-3.7.1.min.js')); ?>"></script>

    <script>


        $(document).ready(function() {
            $('#unit_id, #user_id, #customer_id').select2({
                width: 'resolve' // можно использовать 'resolve' или конкретное значение, например, '150px'
            });
        });


        $(document).ready(function() {
            $('#number_wo').on('input', function() {
                var numberWo = $(this).val();
                var $label = $('#number_wo_label');

                if (numberWo.length === 6) {
                    $.ajax({
                        url: '<?php echo e(route('user.work_orders.checkNumber')); ?>',
                        method: 'POST',
                        data: {
                            number_wo: numberWo,
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        success: function(response) {
                            if (response.exists) {
                                // Показать ошибку в метке и изменить стиль
                                $label.text('Work Order Number is already taken.');
                                $label.addClass('text-danger');
                            } else {
                                // Вернуть исходный текст метки, если нет ошибок
                                $label.text('Work Order Number');
                                $label.removeClass('text-danger');
                            }
                        }
                    });
                } else {
                    // Если количество символов меньше 6, вернуть исходный текст метки
                    $label.text('Work Order Number');
                    $label.removeClass('text-danger');
                }
            });
        });

        function handleFormSubmission(formId, route, selectId, dataKey, dataValue, modalId) {
            document.getElementById(formId).addEventListener('submit', function (event) {
                event.preventDefault();
                if (this.submitted) {
                    return;
                }
                this.submitted = true;

                let formData = new FormData(this);
                fetch(route, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        // Добавляем новый элемент в Select
                        let select = document.getElementById(selectId);
                        let option = document.createElement('option');
                        option.value = data[dataKey];
                        option.text = data[dataValue];
                        option.selected = true; // Автоматически выбираем новый элемент
                        select.add(option);

                        // Закрываем модальное окно
                        let modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
                        modal.hide();

                        // Сброс формы
                        document.getElementById(formId).reset();
                        this.submitted = false;
                    })
                    .catch(error => {
                        console.error('Ошибка:', error);
                        this.submitted = false;
                    });
            });
        }

        document.getElementById('addUnitForm').addEventListener('submit', function (event) {
            event.preventDefault();

            // Если форма уже была отправлена, прерываем дальнейшие действия
            if (this.submitted) {
                return;
            }
            this.submitted = true;

            let formData = new FormData(this);
            fetch('<?php echo e(route('user.unit.storeWorkorder')); ?>', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok: ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        // Добавляем новый элемент в Select
                        let select = document.getElementById('unit_id');
                        let option = document.createElement('option');
                        option.value = data.id;
                        option.text = data.part_number;
                        option.selected = true; // Автоматически выбираем новый элемент
                        select.add(option);

                        // Закрываем модальное окно
                        let modal = bootstrap.Modal.getInstance(document.getElementById('addUnitModal'));
                        modal.hide();

                        // Сброс формы
                        document.getElementById('addUnitForm').reset();
                    } else {
                        console.error('Ошибка:', data.error);
                    }
                    this.submitted = false;
                })
                .catch(error => {
                    console.error('Ошибка:', error);
                    this.submitted = false;
                });
        });




        handleFormSubmission('addInstructionForm', '<?php echo e(route('user.instruction.store')); ?>', 'instruction_id', 'id', 'name', 'addInstructionModal');
        handleFormSubmission('addCustomerForm', '<?php echo e(route('user.customer.store')); ?>', 'customer_id', 'id', 'name', 'addCustomerModal');




    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/user/work_orders/create.blade.php ENDPATH**/ ?>