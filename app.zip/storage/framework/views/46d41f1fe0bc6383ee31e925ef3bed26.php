<?php $__env->startSection('content'); ?>
    <style>
        .container {
            max-width: 450px;
        }

        .push-top {
            margin-top: 50px;
        }
    </style>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e(__('Редактировать пользователя')); ?></h4>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> <!-- Метод PUT для обновления -->

                    <!-- Поле для имени -->
                    <div class="form-group">
                        <label for="name"><?php echo e(__('Name')); ?></label>
                        <input type="text" id="name" class="form-control" name="name"
                               value="<?php echo e(old('name', $user->name)); ?>" required>
                    </div>

                    <!-- Поле для email -->
                    <div class="form-group mt-2">
                        <label for="email"><?php echo e(__('Email')); ?></label>
                        <input type="email" id="email" class="form-control" name="email"
                               value="<?php echo e(old('email', $user->email)); ?>" required>
                    </div>

                    <!-- Поле для аватара -->
                    <div class="form-group mt-2 ">
                        <label for="avatar"><?php echo e(__('Avatar')); ?></label>
                        <div class="d-flex">
                            <?php if($user->avatar): ?>
                                <img src="<?php echo e(asset('storage/avatars/'
                                .$user->avatar)); ?>" style="height: 36px;"
                                     alt="Avatar" class="pe-2 ">
                            <?php endif; ?>
                                <input type="file" name="avatar"
                                       class=" form-control"
                                       placeholder="Avatar">
                        </div>

                    </div>
                    <div class="mt-2">
                        <label for="is_admin"><?php echo e(__('Admin')); ?></label>
                        <input class="form-check-input ms-3" type="checkbox"
                               id="is_admin" name="is_admin"
                               value="1" <?php echo e(old('is_admin', $user->is_admin) ? 'checked' : ''); ?>>
                    </div>

                    <!-- Поле для роли -->
                    <div class="form-group mt-2">
                        <label for="roles_id"><?php echo e(__('Role')); ?></label>
                        <select id="roles_id" name="roles_id" class="form-control" required>
                            <option value=""><?php echo e(__('Select Role')); ?></option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>" <?php echo e($user->roles_id == $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                data-bs-target="#addRoleModal">
                            <?php echo e(__('Add Role')); ?>

                        </button>
                    </div>

                    <!-- Поле для команды -->
                    <div class="form-group mt-2">
                        <label for="teams_id"><?php echo e(__('Team')); ?></label>
                        <select id="teams_id" name="teams_id" class="form-control" required>
                            <option value=""><?php echo e(__('Select Team')); ?></option>
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>" <?php echo e($user->teams_id == $team->id ? 'selected' : ''); ?>><?php echo e($team->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                data-bs-target="#addTeamModal">
                            <?php echo e(__('Add Team')); ?>

                        </button>
                    </div>

                    <!-- Остальные поля -->
                    <div class="mt-2">
                        <label for="phone"><?php echo e(__('Phone')); ?></label>
                        <input id="phone" type="text" class="form-control" name="phone"
                               value="<?php echo e(old('phone', $user->phone)); ?>">
                    </div>

                    <div class="mt-2">
                        <label for="stamp"><?php echo e(__('Stamp')); ?></label>
                        <input id="stamp" type="text" class="form-control" name="stamp"
                               value="<?php echo e(old('stamp', $user->stamp)); ?>">
                    </div>
                    <div class="d-flex justify-content-between">

                        <!-- Кнопка для сохранения изменений -->
                        <button type="submit" class="btn btn-primary mt-3"><?php echo e(__('Обновить')); ?></button>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <!-- Модальное окно для добавления роли -->
    <div class="modal fade" id="addRoleModal" tabindex="-1" aria-labelledby="addRoleLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addRoleModalLabel"><?php echo e(__('Add
                     Role')); ?></h5>
                    
                </div>
                <form method="POST" id="addRoleForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="roleName"><?php echo e(__('Role Name')); ?></label>
                            <input type="text" class="form-control"
                                   id="roleName" name="name" required>
                        </div>
                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save Role')); ?></button>
                    </div>

                </form>
            </div>

        </div>
    </div>

    <!-- Модальное окно для добавления команды -->
    <div class="modal fade" id="addTeamModal" tabindex="-1" aria-labelledby="addTeamLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTeamModalLabel"><?php echo e(__('Add Team')); ?></h5>
                    

                </div>
                <form method="POST" id="addTeamForm">
                    <?php echo csrf_field(); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="teamName"><?php echo e(__('Team Name')); ?></label>
                            <input type="text" class="form-control"
                                   id="teamName" name="name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save Team')); ?></button>
                    </div>
            </div>
            </form>
        </div>
    </div>


    <script>
        function handleFormSubmission(formId, modalId, route, selectId,
                                      dataKey,
                                      dataValue) {
            document.getElementById(formId).addEventListener('submit', function (event) {
                event.preventDefault(); // Предотвращаем стандартную отправку формы
                if (this.submitted) {
                    return;
                }
                let formData = new FormData(this);
                fetch(route, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        // 1. Добавляем новую опцию в select
                        let select = document.getElementById(selectId);
                        let option = document.createElement('option');
                        option.value = data[dataKey]; // ID новой роли
                        option.text = data[dataValue]; // Имя новой роли
                        select.add(option);

                        // 2. Закрываем модальное окно вручную
                        let modalElement = document.getElementById(modalId);

                        if (modalElement) {
                            let modal = bootstrap.Modal.getInstance(modalElement);
                            if (modal) {
                                modal.hide();
                            } else {
                                // Если нет экземпляра, создайте новый и закройте его
                                let newModal = new bootstrap.Modal(modalElement);
                                newModal.hide();
                            }
                        }
                        // 3. Очистка формы
                        // document.getElementById(formId).reset();
                    })
                    .catch(error => {
                        console.error('Ошибка:', error);
                        alert('Произошла ошибка при добавлении.');
                    });
            });
        }

        // Пример использования для ролей
        handleFormSubmission('addRoleForm', 'addRoleModal', '<?php echo e(route('admin.roles.store')); ?>', 'roles_id', 'id', 'name');

        // Пример использования для команд
        handleFormSubmission('addTeamForm', 'addTeamModal', '<?php echo e(route('admin.teams.store')); ?>', 'teams_id', 'id', 'name');
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>