<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">

       <span></span>
    </div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>"
                                               class="btn btn-primary">Home</a></li>

                <li class="nav-item ms-2"><a href="<?php echo e(route('user.work_orders.index')); ?>"
                                               class="btn
                                               btn-primary"><?php echo e(__('Work Orders')); ?></a></li>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->is_admin): ?>

                        <li class="nav-item ms-2">
                            <h3>
                                <a href="<?php echo e(route('admin.cmms.index')); ?>" class="btn btn-primary">CMM</a>
                            </h3>

                        </li>
                        <li class="nav-item ms-2">
                            <h3>
                                <a href="<?php echo e(route('admin.units.index')); ?>" class="btn btn-primary"
                                >Units</a>
                            </h3>

                        </li>
                        <li class="nav-item ms-2">
                            <h3>
                                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary"
                                >Users</a>
                            </h3>

                        </li>
                        <li class="nav-item ms-2">
                            <h3>
                                <a href="<?php echo e(route('admin.customers.index')); ?>" class="btn btn-primary"
                                >Customers</a>
                            </h3>

                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ol>
        </nav>
    </div>












</div>
<?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/includes/admin_nav.blade.php ENDPATH**/ ?>