<?php $__env->startSection('content'); ?>
    <style>
        /* Скрываем колонки Phone и Stamp при ширине экрана < 1100px */
        @media (max-width: 1100px) {
            .table th:nth-child(7),
            .table td:nth-child(7), /* Phone */
            .table th:nth-child(8),
            .table td:nth-child(8) /* Stamp */
            {
                display: none;
            }
        }

        /* Скрываем Email, Admin, Role, Team, Phone, Stamp при ширине экрана < 770px */
        @media (max-width: 770px) {
            .table th:nth-child(3),
            .table td:nth-child(3), /* Email */
            .table th:nth-child(4),
            .table td:nth-child(4), /* Admin */
            .table th:nth-child(5),
            .table td:nth-child(5), /* Role */
            .table th:nth-child(6),
            .table td:nth-child(6), /* Team */
            .table th:nth-child(7),
            .table td:nth-child(7), /* Phone */
            .table th:nth-child(8),
            .table td:nth-child(8) /* Stamp */
            {
                display: none;
            }
        }

        /* Скрываем колонку Avatar при ширине экрана < 412px */
        @media (max-width: 412px) {
            .table th:nth-child(1),
            .table td:nth-child(1) /* Avatar */
            {
                display: none;
            }

            /* Скрываем таблицу и отображаем сообщение о доступности только для десктоп */
            .table {
                display: none;
            }

            #mobile-message {
                display: block;
            }
        }
    </style>

    <div class="container">
        <div class="card shadow">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h3><?php echo e(__('Users')); ?></h3>
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary mb-3">
                        <?php echo e(__('Create User')); ?>

                    </a>
                </div>

            </div>
            <div class="card-body">
                <table id="userTable"
                    data-toggle="table"
                    data-search="true"
                    data-pagination="false"
                    data-page-size="10"
                    class="table table-bordered" >
                    <thead>
                    <tr>
                        <th data-field="avatar" data-visible="true" data-priority="1">
                            <?php echo e(__('Avatar')); ?></th>
                        <th data-field="name" data-visible="true" data-priority="2">
                            <?php echo e(__('Name')); ?></th>
                        <th data-field="email" data-visible="true" data-priority="4">
                            <?php echo e(__('Email')); ?></th>
                        <th data-field="is_admin" data-visible="true" data-priority="5">
                            <?php echo e(__('Admin')); ?></th>
                        <th data-field="roles_id" data-visible="true" data-priority="6">
                            <?php echo e(__('Role')); ?></th>
                        <th data-field="teams_id" data-visible="true" data-priority="7">
                            <?php echo e(__('Team')); ?></th>
                        <th data-field="phone" data-visible="true" data-priority="8">
                            <?php echo e(__('Phone')); ?></th>
                        <th data-field="stamp" data-visible="true" data-priority="9">
                            <?php echo e(__('Stamp')); ?></th>
                        <th data-field="action" data-visible="true" data-priority="3">
                            <?php echo e(__('Action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="#" data-bs-toggle="modal"
                                   data-bs-target="#imageModal<?php echo e($user->id); ?>">
                                    <img src="<?php echo e(asset('storage/avatars/' . $user->avatar)); ?>"
                                         style="height: 50px; cursor: pointer;"
                                         alt="Img"
                                    />
                                </a>
                            </td>


                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->is_admin ? 'Yes' : 'No'); ?></td>
                            <td><?php echo e($user->role->name ?? 'No Role'); ?></td> <!-- Используйте роль -->
                            <td><?php echo e($user->team->name ?? 'No Team'); ?></td> <!-- Используйте команду -->
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->stamp); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                   class="btn btn-primary btn-sm">

                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST"
                                      style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure?');">

                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

    <div id="mobile-message" style="display: none; text-align: center;">
        <p>Only desktop version available.</p>
    </div>


    <!-- Модальное окно для показа большого изображения -->

    <div class="modal fade" id="imageModal<?php echo e($user->id); ?>" tabindex="-1"
         role="dialog" aria-labelledby="imageModalLabel<?php echo e($user->id); ?>"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"
                        id="imageModalLabel<?php echo e($user->id); ?>"><?php echo e($user->name); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if($user->avatar): ?>
                        <img src="<?php echo e(asset('storage/avatars/' . $user->avatar)); ?>"
                             alt="<?php echo e($user->name); ?>" class="img-fluid"/>
                    <?php else: ?>
                        <p>No avatar available.</p>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        // Проверка ширины экрана и управление отображением таблицы и сообщения
        function checkScreenWidth() {
            const screenWidth = window.innerWidth;
            const table = document.querySelector('.table');
            const mobileMessage = document.getElementById('mobile-message');

            if (screenWidth < 412) {
                table.style.display = 'none';
                mobileMessage.style.display = 'block';
            } else {
                table.style.display = 'table';
                mobileMessage.style.display = 'none';
            }
        }

        window.onload = checkScreenWidth;
        window.onresize = checkScreenWidth;


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/admin/users/index.blade.php ENDPATH**/ ?>