<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Work</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>" class="btn btn-primary">Home</a></li>

            </ol>
        </nav>
    </div>












</div>
<?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/includes/work_nav.blade.php ENDPATH**/ ?>