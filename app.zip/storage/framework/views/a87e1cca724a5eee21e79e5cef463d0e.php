<?php $__env->startSection('content'); ?>

    <style>
        .card {
            max-width: 450px;
        }
    </style>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e(__('Select Unit')); ?></h4>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('user.trainings.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mt-2">
                        <label for="manuals_id"><?php echo e(__('Unit PN')); ?></label>
                        <select id="manuals_id" name="manuals_id" class="form-control" required>
                            <option value=""><?php echo e(__('Select Unit PN')); ?></option>
                            <?php $__currentLoopData = $manuals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($manual->id); ?>"><?php echo e($manual->title); ?> (<?php echo e($manual->units_pn); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group mt-3">
                        <label for="date_training"><?php echo e(__('First Training Date')); ?></label>
                        <input type="date" id="date_training" name="date_training" class="form-control" required>
                    </div>



                    <button type="submit" class="btn btn-primary mt-3"><?php echo e(__('Add Unit')); ?></button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/user/trainings/create.blade.php ENDPATH**/ ?>