<div class="list-item">
    <ul class="list-link">
        <li class="">
            <a href="#" data-bs-toggle="tooltip" title="Home">
                <i class="bi bi-house-door icon"></i>
                <span class="text nav-text"><?php echo e(__('Home')); ?></span>
            </a>
        </li>
        <li class="#" >
            <a href="<?php echo e(route('user.trainings.index')); ?>" data-bs-toggle="tooltip" title="Training">
                <i class='bi bi-trophy icon'></i>
                <span class="text nav-text"><?php echo e(__('Training')); ?></span>
            </a>
        </li>
        <li class="">
            <a href="#" data-bs-toggle="tooltip" title="Tools">
                <i class="bi bi-tools  icon"></i>
                <span class="text nav-text"><?php echo e(__('Tools')); ?></span>
            </a>
        </li>
        <li class="">
            <a href="#" data-bs-toggle="tooltip" title="Materials">
                <i class="bi bi-minecart icon"></i>
                <span class="text nav-text"><?php echo e(__('Materials')); ?></span>
            </a>
        </li>
        <li class="">
            <a href="#" data-bs-toggle="tooltip" title="Tests">
                <i class="bi bi-journal-check icon"></i>
                <span class="text nav-text"><?php echo e(__('Tests')); ?></span>
            </a>
        </li>
        <li class="">
            <a href="#" data-bs-toggle="tooltip" title="Notification">
                <i class='bi bi-bell icon'></i>
                <span class="text nav-text"><?php echo e(__('Notification')); ?></span>
            </a>
        </li>
        <li class="">
            <a href="#" data-bs-toggle="tooltip" title="Standart Processes">
                <i class="bi bi-list-columns-reverse icon"></i>
                <span class="text nav-text"><?php echo e(__('Standart
                            Processes')); ?></span>
            </a>
        </li>
    </ul>
</div>
<?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/includes/sidebar_main.blade.php ENDPATH**/ ?>