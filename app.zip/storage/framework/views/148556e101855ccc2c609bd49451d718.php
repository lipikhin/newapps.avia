<?php $__env->startSection('content'); ?>
    <style>



        @media (max-width: 1100px) {
            .table th:nth-child(5),
            .table td:nth-child(5) {
                display: none;
            }
        }

        @media (max-width: 770px) {
            .table th:nth-child(3),
            .table td:nth-child(3), /* Revision Date */
            .table th:nth-child(5),
            .table td:nth-child(5), /* Revision Date */
            .table th:nth-child(6),
            .table td:nth-child(6) {
                display: none;
            }
        }

        @media (max-width: 490px) {
            .table th:nth-child(3), /* Image */
            .table td:nth-child(3),
            .table th:nth-child(4), /* Revision Date */
            .table td:nth-child(4),
            .table th:nth-child(5), /* Revision Date */
            .table td:nth-child(5),
            .table th:nth-child(6),
            .table td:nth-child(6) {
                display: none;
            }
        }
    </style>

    <div class="container">
        <div class="card shadow">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h3><?php echo e(__('Manage CMMs')); ?></h3>
                    <a href="<?php echo e(route('admin.cmms.create')); ?>" class="btn
                    btn-primary mb-3"><?php echo e(__('Add CMM')); ?></a>
                </div>
            </div>

            <div class="card-body">
                <table id="cmmTable"
                       data-toggle="table"
                       data-search="true"
                       data-pagination="false"
                       data-page-size="5"
                       class="table table-bordered">
                    <thead>
                    <tr>
                        <th data-field="number" data-visible="true"
                            data-priority="1" class="text-center"><?php echo e(__
                            ('Number')); ?> </th>
                        <th data-field="title" data-visible="true"
                            data-priority="2" class="text-center"><?php echo e(__
                        ('Title')); ?></th>
                        <th data-field="units_pn" data-visible="true"
                            data-priority="3" class="text-center"><?php echo e(__
                        ('Units PN')); ?></th>
                        <th data-field="img" data-visible="true"
                            data-priority="4" class="text-center"><?php echo e(__
                        ('Unit Image')); ?></th>
                        <th data-field="revision_date" data-visible="true"
                            data-priority="5"
                            class="text-center"><?php echo e(__('Revision Date')); ?></th>
                        <th data-field="lib" data-visible="true" data-priority="6"
                            class="text-center"><?php echo e(__('Library')); ?></th>
                        <th data-field="action" data-visible="true"
                            data-priority="7" class="text-center"><?php echo e(__
                        ('Action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $cmms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($cmm->number); ?></td>
                            <td class="text-center"><?php echo e($cmm->title); ?></td>
                            <td class="text-center"><?php echo e($cmm->units_pn); ?></td>

                            <td class="text-center">
                                <a href="#" data-bs-toggle="modal"
                                   data-bs-target="#imageModal<?php echo e($cmm->id); ?>">
                                    <img src="<?php echo e(asset('storage/image/cmm/' . $cmm->img)); ?>" style="width: 36px; cursor: pointer;"
                                         alt="Img">
                                </a>
                            </td>

                            <td class="text-center"><?php echo e($cmm->revision_date); ?></td>
                            <td class="text-center"><?php echo e($cmm->lib); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.cmms.edit', $cmm->id)); ?>"
                                   class="btn btn-primary btn-sm">
                                    <i class="bi bi-pencil-square"></i>

                                </a>
                                <form action="<?php echo e(route('admin.cmms.destroy', $cmm->id)); ?>" method="POST"
                                      style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure?');">

                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>

                        <!-- Image Modal -->
                        <div class="modal fade" id="imageModal<?php echo e($cmm->id); ?>" tabindex="-1" role="dialog"
                             aria-labelledby="imageModalLabel<?php echo e($cmm->id); ?>"
                             aria-hidden="true">
                            <div class="modal-dialog ">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="imageModalLabel<?php echo e($cmm->id); ?>">
                                            <?php echo e($cmm->title); ?>

                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                    </div>

                                    <div class="modal-body">
                                        <?php if($cmm->img): ?>
                                            <img src="<?php echo e(asset('storage/image/cmm/' . $cmm->img)); ?>"
                                                 alt="<?php echo e($cmm->title); ?>" class="img-fluid"/>
                                        <?php else: ?>
                                            <p>No image available.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
        <div id="mobile-message" style="display: none; text-align: center;">
            <p>Only desktop version available.</p>
        </div>


        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>
            <script>

                // Проверка ширины экрана и управление отображением таблицы и сообщения
                function checkScreenWidth() {
                    const screenWidth = window.innerWidth;
                    const table = document.querySelector('.table');
                    const mobileMessage = document.getElementById('mobile-message'); // Если хотите использовать это сообщение, добавьте его в HTML.

                    if (screenWidth < 312) {
                        table.style.display = 'none';
                        if (mobileMessage) mobileMessage.style.display = 'block';
                    } else {
                        table.style.display = 'table';
                        if (mobileMessage) mobileMessage.style.display = 'none';
                    }
                }

                window.onload = checkScreenWidth;
                window.onresize = checkScreenWidth;
            </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/admin/cmms/index.blade.php ENDPATH**/ ?>