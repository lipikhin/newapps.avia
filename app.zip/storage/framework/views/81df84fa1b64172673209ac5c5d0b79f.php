<?php $__env->startSection('content'); ?>
    <style>
        .container {
            max-width: 650px;
        }

    </style>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h5><strong><?php echo e(__('Edit CMM:')); ?></strong> <?php echo e($cmm->number); ?></h5>
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.cmms.update', $cmm->id)); ?>" enctype="multipart/form-data"
                      id="editCMMForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group d-flex ">
                        <div class="mt-2 m-3 border p-2">
                            <div>
                                <label for="cmm_num"><?php echo e(__('CMM Number')); ?></label>
                                <input id='cmm_num' type="text"
                                       class="form-control" name="number" value="<?php echo e(old('number', $cmm->number)); ?>"
                                       required>
                                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mt-2">
                                <label for="title"><?php echo e(__('Description')); ?></label>
                                <input id='title' type="text" class="form-control" name="title"
                                       value="<?php echo e(old('title', $cmm->title)); ?>" required>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 mt-2">
                                <div class="form-group">
                                    <strong><?php echo e(__('Image:')); ?></strong>
                                    <input type="file" name="img" class="form-control" placeholder="изображение">
                                    <small><?php echo e(__('Leave blank if you do not want to change the image.')); ?></small>
                                </div>
                            </div>

                            <div class="">
                                <label for="revision_date"><?php echo e(__('Revision Date')); ?></label>
                                <input id='revision_date' type="date" class="form-control" name="revision_date"
                                       value="<?php echo e(old('revision_date', $cmm->revision_date)); ?>" required>
                            </div>
                            <div class="mt-2">
                                <label for="units_pn"><?php echo e(__('Units PN')); ?></label>
                                <input id='units_pn' type="text" class="form-control" name="units_pn" value="<?php echo e(old
                                ('units_pn',
                                $cmm->units_pn)); ?>" required>
                            </div>
                            <div class="mt-2">
                                <label for="units_tr"><?php echo e(__('Unit First
                                Training')); ?></label>
                                <input id='units_tr' type="text"
                                       class="form-control" name="units_tr"
                                       value="<?php echo e(old('units_tr', $cmm->units_tr)); ?>" required>
                            </div>
                        </div>
                        <div style="width: 300px" class="m-3 p-2 border">
                            <div class="form-group ">
                                <label for="planes_id"><?php echo e(__('AirCraft Type')); ?></label>
                                <select id="planes_id" name="planes_id" class="form-control" required>
                                    <option value=""><?php echo e(__('Select AirCraft')); ?></option>
                                    <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($plane->id); ?>" <?php echo e($plane->id == $cmm->planes_id ?
                                        'selected' : ''); ?>><?php echo e($plane->type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                        data-bs-target="#addAirCraftModal"><?php echo e(__('Add AirCraft')); ?></button>
                            </div>

                            <div class="form-group mt-2 ">
                                <label for="builders_id"><?php echo e(__('MFR')); ?></label>
                                <select id="builders_id" name="builders_id" class="form-control" required>
                                    <option value=""><?php echo e(__('Select MFR')); ?></option>
                                    <?php $__currentLoopData = $builders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $builder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($builder->id); ?>" <?php echo e($builder->id == $cmm->builders_id ?
                                        'selected' : ''); ?>><?php echo e($builder->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="button" class="btn btn-link" data-bs-toggle="modal"
                                        data-bs-target="#addMFRModal"><?php echo e(__('Add MFR')); ?></button>
                            </div>

                            <div class="form-group mt-2">
                                <label for="scopes_id"><?php echo e(__('Scope')); ?></label>
                                <select id="scopes_id" name="scopes_id" class="form-control" required>
                                    <option value=""><?php echo e(__('Select Scope')); ?></option>
                                    <?php $__currentLoopData = $scopes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($scope->id); ?>" <?php echo e($scope->id == $cmm->scopes_id ? 'selected' : ''); ?>><?php echo e($scope->scope); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="button" class="btn btn-link " data-bs-toggle="modal"
                                        data-bs-target="#addScopeModal"><?php echo e(__('Add Scope')); ?></button>
                            </div>
                            <div class="">
                                <label for="lib"><?php echo e(__('Library Number')); ?></label>
                                <input id='lib' type="text" class="form-control" name="lib"
                                       value="<?php echo e(old('lib', $cmm->lib)); ?>" required>
                            </div>

                        </div>

                    </div>

                    <button type="submit" class="btn btn-primary text-center ">
                        <?php echo e(__('UpDate')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Модальное окно для добавления самолета -->
    <div class="modal fade" id="addAirCraftModal" tabindex="-1" aria-labelledby="addAirCraftModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addAirCraftModalLabel"><?php echo e(__
                    ('Add AirCraft')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
                </div>
                <form method="POST" id="addAirCraftForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="airCraftName"><?php echo e(__('Type AirCraft')); ?></label>
                            <input type="text" class="form-control" id="airCraftName" name="type" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__
                        ('Save')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Модальное окно для добавления MFR -->
    <div class="modal fade" id="addMFRModal" tabindex="-1" aria-labelledby="addMFRModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMFRModalLabel"><?php echo e(__('Add
                    MFR')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
                </div>
                <form method="POST" id="addMFRForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="mfrName"><?php echo e(__('Name MFR')); ?></label>
                            <input type="text" class="form-control" id="mfrName" name="name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__
                        ('Save')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Модальное окно для добавления Scope -->
    <div class="modal fade" id="addScopeModal" tabindex="-1" aria-labelledby="addScopeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addScopeModalLabel"><?php echo e(__('Add
                    Scope')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
                </div>
                <form method="POST" id="addScopeForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="scopeName"><?php echo e(__('Name Scope')); ?></label>
                            <input type="text" class="form-control" id="scopeName" name="scope" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__
                        ('Save')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Функция для обработки отправки форм для самолетов, MFR и Scope
        function handleFormSubmission(formId, modalId, route, selectId, dataKey, dataValue) {
            document.getElementById(formId).addEventListener('submit', function (event) {
                event.preventDefault();
                let formData = new FormData(this);
                fetch(route, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        let select = document.getElementById(selectId);
                        let option = document.createElement('option');
                        option.value = data[dataKey];
                        option.text = data[dataValue];
                        select.add(option);

                        // 2. Закрываем модальное окно вручную
                        let modalElement = document.getElementById(modalId);

                        if (modalElement) {
                            let modal = bootstrap.Modal.getInstance(modalElement);
                            if (modal) {
                                modal.hide();
                            } else {
                                // Если нет экземпляра, создайте новый и закройте его
                                let newModal = new bootstrap.Modal(modalElement);
                                newModal.hide();
                            }
                        }
                        // 3. Очистка формы
                        // document.getElementById(formId).reset();
                    })
                    .catch(error => console.error('Ошибка:', error));
            });
        }

        handleFormSubmission('addAirCraftForm', 'addAirCraftModal', '<?php echo e(route('admin.planes.store')); ?>',
            'planes_id', 'id', 'type');
        handleFormSubmission('addMFRForm', 'addMFRModal', '<?php echo e(route('admin.builders.store')); ?>', 'builders_id', 'id',
            'name');
        handleFormSubmission('addScopeForm', 'addScopeModal', '<?php echo e(route('admin.scopes.store')); ?>', 'scopes_id', 'id', 'scope');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/admin/cmms/edit.blade.php ENDPATH**/ ?>