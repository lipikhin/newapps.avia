<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Profile')); ?></div>

                    <div class="card-body">
                        <form id="profile-form" method="POST" action="<?php echo e(route('user.profile.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <!-- Профильная информация -->
                            <div class="row">
                                <div class="d-flex justify-content-center">
                                    <?php if(auth()->user()->avatar): ?>
                                        <img id="avatar-preview"
                                             src="<?php echo e(asset
                                             ('/storage/avatars/' . auth()->user()->avatar)); ?>"
                                             style="width:120px; margin-top: 10px; cursor: pointer;">

                                    <?php else: ?>
                                        <img id="avatar-preview"
                                             src="<?php echo e(asset
                                             ('public/image/noimage.png' .
                                             auth()->user()->avatar)); ?>"
                                             style="width:120px; margin-top: 10px; cursor: pointer;">

                                    <?php endif; ?>
                                        <input id="avatar" type="file" class="d-none <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="avatar" accept="image/*">
                                        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span role="alert" class="text-danger"><strong><?php echo e($message); ?></strong></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="name" class="form-label">Name: </label>
                                    <input class="form-control" type="text" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>" autofocus="">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span role="alert" class="text-danger">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="email" class="form-label">Email: </label>
                                    <input class="form-control" type="text" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>" autofocus="">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span role="alert" class="text-danger">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Signature file-->

                            <div class="col-xs-12 col-sm-12 col-md-12 mt-2">
                                <div class="form-group">
                                    <?php echo e(__('Signature:')); ?>


                                    <input type="file" name="sign"
                                           class="form-control"
                                           placeholder="image">
                                </div>
                                <h6 style="font-size: 0.75rem;"><?php echo e(__
                                    ('(Image with resolution 200px : 100px)')); ?></h6>
                            </div>

                            <!-- Остальные поля профиля -->
                            <div class="row ">
                                <div class="mb-3 col-md-6 mt-2">
                                    <label for="phone" class="form-label">Phone: </label>
                                    <input class="form-control" type="text" id="phone" name="phone" value="<?php echo e(auth()->user()->phone); ?>" autofocus="">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span role="alert" class="text-danger">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3 col-md-6 mt-2">
                                    <label for="stamp" class="form-label">Stamp: </label>
                                    <input class="form-control" type="text" id="stamp" name="stamp" value="<?php echo e(auth()->user()->stamp); ?>" autofocus="">
                                    <?php $__errorArgs = ['stamp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span role="alert" class="text-danger">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Добавляем кнопку изменения пароля -->
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                                        Change Password
                                    </button>
                                </div>
                            </div>

                            <!-- Кнопки обновления профиля -->
                            <div class="row mb-0">
                                <div class="col-md-12 d-flex justify-content-center">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update Profile')); ?></button>
                                    <button type="button" id="cancel-button" class="btn btn-secondary ms-2">
                                        <a href="/home" style="color: white"><?php echo e(__('Cancel')); ?></a>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Модальное окно для изменения пароля -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('user.profile.changePassword')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="old_password" class="form-label">Old Password:</label>
                            <input type="password" class="form-control" id="old_password" name="old_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password:</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="new_password_confirmation" class="form-label">Confirm Password:</label>
                            <input type="password" class="form-control" id="new_password_confirmation" name="new_password_confirmation" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Сохранить начальное состояние формы
        const initialAvatarSrc = document.getElementById('avatar-preview').src; // Исправлено здесь
        const initialFormState = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            stamp: document.getElementById('stamp').value,
        };

        // Нажатие на аватар для выбора файла
        document.getElementById('avatar-preview').addEventListener('click', function() {
            document.getElementById('avatar').click(); // Открытие диалогового окна для выбора файла
        });

        // Предпросмотр нового аватара после выбора файла
        document.getElementById('avatar').addEventListener('change', function() {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('avatar-preview').src = e.target.result; // Обновление изображения
            };
            if (this.files && this.files[0]) {
                reader.readAsDataURL(this.files[0]); // Чтение выбранного файла
            }
        });

        // Сброс полей формы в начальное состояние
        document.getElementById('cancel-button').addEventListener('click', function() {
            document.getElementById('avatar-preview').src = initialAvatarSrc; // Исправлено здесь
            document.getElementById('avatar').value = ''; // Очистка значения ввода
            document.getElementById('name').value = initialFormState.name;
            document.getElementById('email').value = initialFormState.email;
            document.getElementById('phone').value = initialFormState.phone;
            document.getElementById('stamp').value = initialFormState.stamp;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/user/profile/profile.blade.php ENDPATH**/ ?>