<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'AVL_Code')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css">

    <!-- Styles -->
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        .video-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
        }
        .content {
            position: relative;
            z-index: 2;
            text-align: center;
            color: white;
        }
        .colored-svg {
            width: 180px; /* Установите желаемую ширину */
            height: auto; /* Высота будет автоматически скорректирована пропорционально */
            /*filter: invert(31%) sepia(84%) saturate(5873%) hue-rotate(355deg) brightness(101%) contrast(106%);*/
            filter: brightness(0) saturate(100%) invert(24%) sepia(95%) saturate(2178%) hue-rotate(210deg) brightness(108%) contrast(98%);
            /* Настройте фильтры для получения желаемого цвета */
        }
    </style>
</head>
<body>
<video autoplay loop muted playsinline class="video-background">
    <source src="<?php echo e(asset('video/background.mp4')); ?>" type="video/mp4">
    Your browser does not support the video tag.
</video>

<div class="container">
    <div class="navbar navbar-expand-md">
        <div class="navbar-nav me-auto">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('image/AT_logo-rb.svg')); ?>" alt="Logo"
                     class="colored-svg">
                
            </a>
        </div>

        <div class="navbar-nav ms-auto" >
            <?php if(Route::has('login')): ?>
                <div class="nav justify-content-end" >
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="nav-link" aria-current="page">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="nav-link "
                           aria-current="page" >Log in</a>
                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="nav-link" aria-current="page">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <div class="content">
        
        
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/welcome.blade.php ENDPATH**/ ?>