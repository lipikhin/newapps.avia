<?php $__env->startSection('content'); ?>
    <style>
        @media (max-width: 1400px) {
            .table th:nth-child(8),
            .table td:nth-child(8) {
                display: none;
            }
        }
        @media (max-width: 1250px) {

            .table th:nth-child(8),
            .table td:nth-child(8),
            .table th:nth-child(9),
            .table td:nth-child(9) {
                display: none;
            }
        }
        @media (max-width: 1050px) {

            .table th:nth-child(7),
            .table td:nth-child(7),
            .table th:nth-child(8),
            .table td:nth-child(8),
            .table th:nth-child(9),
            .table td:nth-child(9) {
                display: none;
            }
        }
        @media (max-width: 1000px) {
            .table th:nth-child(2),
            .table td:nth-child(2),

            .table th:nth-child(7),
            .table td:nth-child(7),
            .table th:nth-child(8),
            .table td:nth-child(8),
            .table th:nth-child(9),
            .table td:nth-child(9) {
                display: none;
            }
        }

    </style>

    <div class="container">
        <div class="card shadow">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h3><?php echo e(__('Work Orders')); ?></h3>
                    <a href="<?php echo e(route('user.work_orders.create')); ?>"
                       class="btn
                    btn-primary mb-3"><?php echo e(__('Add WorkOrder')); ?></a>
                </div>
            </div>
            <div class="card-body">
                <table id="woTable"
                       data-toggle="table"
                       data-search="true"
                       data-pagination="false"
                       data-show-columns="false"
                       data-show-export="false"
                       data-show-refresh="false"
                       data-filter-control="true"
                       data-filter-show-clear="true"
                       class="table table-bordered">
                    <thead>
                    <tr>
                        <th data-field="number_wo" data-visible="true" data-priority="1" class="text-center align-middle">
                            <?php echo e(__('Number')); ?>

                        </th>
                        <th data-field="description" data-visible="true"
                            data-priority="2" class="text-center align-middle">
                            <?php echo e(__('Description')); ?>

                        </th>
                        <th data-field="unit_id" data-visible="true"
                            data-priority="3" class="text-center align-middle">
                            <?php echo e(__('Part Number')); ?>

                        </th>
                        <th data-field="serial_number" data-visible="true" data-priority="4" class="text-center align-middle">
                            <?php echo e(__('Serial Number')); ?>

                        </th>
                        <th data-field="customer" data-visible="true"
                            data-priority="5" class="text-center align-middle">
                            <?php echo e(__('Customer')); ?>

                        </th>
                        <th data-field="instruction" data-visible="true"
                            data-priority="6" class="text-center align-middle">
                            <?php echo e(__('Instruction')); ?>

                        </th>
                        <th data-field="open" data-visible="true" data-priority="7" class="text-center align-middle">
                            <?php echo e(__('Open')); ?>

                        </th>
                        <th data-field="technician" data-visible="true"
                            data-priority="8" class="text-center align-middle">
                            <?php echo e(__('Technician')); ?>

                        </th>
                        <th data-field="approve" data-visible="true" data-priority="9" class="text-center align-middle">
                            <?php echo e(__('Approved')); ?>

                        </th>
                        <th data-field="action" data-visible="true" data-priority="10" class="text-center align-middle">
                            <?php echo e(__('Action')); ?>

                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $wos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center align-middle" style="font-size: 12px"> <?php echo e($wo->number_wo); ?></td>
                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->unit->manuals->title); ?></td>

                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->unit->part_number); ?>

                                <?php if(!empty($wo->amdt)): ?>
                                    "<?php echo e($wo->amdt); ?>"
                                <?php endif; ?>
                            </td>

                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->serial_number); ?></td>
                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->customer->name); ?></td>
                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->instruction->name); ?></td>
                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->open_at); ?></td>
                            <td class="text-center align-middle" style="font-size: 12px"><?php echo e($wo->user->name); ?></td>
                            <td class="text-center align-middle" style="font-size: 16px">
                                <?php if($wo->approve === true): ?>
                                    <i class="bi bi-check2 success"></i>
                                <?php else: ?>
                                    <i class="bi bi-x"></i>
                                <?php endif; ?>
                            </td>
                            <td class="text-center align-middle">
                                <a href="<?php echo e(route('user.work_orders.edit', $wo->id)); ?>" class="btn btn-primary btn-sm">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <form action="<?php echo e(route('user.work_orders.destroy', $wo->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_dlb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\newapps.avia\resources\views/user/work_orders/index.blade.php ENDPATH**/ ?>