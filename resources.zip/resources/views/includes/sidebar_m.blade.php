<nav class="sidebar-nav">
    <ul class="metismenu" id="sidenav">


            <a href="{{route('user.trainings.index')}}"
               class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                <i class="fas fa-light fa-trophy"></i>
                {{__('Training')}}
            </a>

    </ul>
</nav>
