<nav class="sidebar-nav">
    <ul class="metismenu" id="sidenav">

        <li>
            <a class="nav-link" href="{{route('user.trainings.index')}}">
                <span class="material-symbols-outlined mb-2 me-1">trophy</span>
                <h5> <strong>{{__('Training')}}</strong></h5>
            </a>
        </li>

    </ul>
</nav>
